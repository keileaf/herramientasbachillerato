# Ayudante de Subtitulos en vivo - Colegio La Paz
# - Barra de subtitulos transparente, siempre encima (WPF)
# - Servidor local en http://localhost:8765 que recibe el texto desde la pagina
# - Icono junto al reloj de Windows: clic derecho > Salir
param([switch]$NoBrowser)

$port = 8765
$base = "http://localhost:$port/"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $root.EndsWith('\')) { $root = $root + '\' }
$pageUrl = $base + 'subtitulos.html'

function Open-Browser {
    foreach ($b in @('chrome', 'msedge')) {
        try { Start-Process $b $pageUrl -ErrorAction Stop; return } catch {}
    }
    Start-Process $pageUrl
}

# ---------- Servidor local ----------
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add($base)
try {
    $listener.Start()
} catch {
    # Probablemente ya esta abierto
    if (-not $NoBrowser) { Open-Browser }
    exit
}

$sync = [hashtable]::Synchronized(@{ data = $null; ver = 0; cmd = $null; visible = $false; root = $root })

$serverScript = {
    param($listener, $sync)
    $types = @{
        '.html' = 'text/html; charset=utf-8'; '.js' = 'application/javascript; charset=utf-8'
        '.css' = 'text/css; charset=utf-8'; '.json' = 'application/json; charset=utf-8'
        '.png' = 'image/png'; '.jpg' = 'image/jpeg'; '.svg' = 'image/svg+xml'; '.ico' = 'image/x-icon'
    }
    function Send($ctx, [int]$code, [string]$type, [byte[]]$bytes) {
        $res = $ctx.Response
        $res.StatusCode = $code
        if ($type) { $res.ContentType = $type }
        # Permite que la pagina publicada en GitHub hable con este ayudante
        $origin = $ctx.Request.Headers['Origin']
        if (-not $origin) { $origin = '*' }
        $res.Headers.Add('Access-Control-Allow-Origin', $origin)
        $res.Headers.Add('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        $res.Headers.Add('Access-Control-Allow-Headers', 'Content-Type')
        $res.Headers.Add('Access-Control-Allow-Private-Network', 'true')
        $res.Headers.Add('Vary', 'Origin')
        $res.Headers.Add('Cache-Control', 'no-store')
        $res.ContentLength64 = $bytes.Length
        if ($bytes.Length -gt 0) { $res.OutputStream.Write($bytes, 0, $bytes.Length) }
        $res.OutputStream.Close()
    }
    function SendJson($ctx, [string]$json) { Send $ctx 200 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)) }
    function VisJson { '{"visible":' + $sync.visible.ToString().ToLower() + '}' }

    while ($listener.IsListening) {
        try { $ctx = $listener.GetContext() } catch { break }
        try {
            $req = $ctx.Request
            $path = [Uri]::UnescapeDataString($req.Url.AbsolutePath)
            if ($req.HttpMethod -eq 'OPTIONS') {
                Send $ctx 204 $null ([byte[]]@())
            } elseif ($path -eq '/api/ping') {
                SendJson $ctx '{"ok":true,"overlay":true,"version":2}'
            } elseif ($path -eq '/api/overlay' -and $req.HttpMethod -eq 'POST') {
                $reader = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
                $body = $reader.ReadToEnd(); $reader.Close()
                $sync.data = $body
                $sync.ver = $sync.ver + 1
                SendJson $ctx (VisJson)
            } elseif ($path -eq '/api/overlay/show') {
                $sync.cmd = 'show'; $sync.visible = $true; SendJson $ctx (VisJson)
            } elseif ($path -eq '/api/overlay/hide') {
                $sync.cmd = 'hide'; $sync.visible = $false; SendJson $ctx (VisJson)
            } elseif ($path -eq '/api/overlay/state') {
                SendJson $ctx (VisJson)
            } else {
                if ($path -eq '/') { $path = '/subtitulos.html' }
                $full = [IO.Path]::GetFullPath([IO.Path]::Combine($sync.root, $path.TrimStart('/').Replace('/', '\')))
                if ($full.StartsWith($sync.root, [StringComparison]::OrdinalIgnoreCase) -and [IO.File]::Exists($full)) {
                    $type = $types[[IO.Path]::GetExtension($full).ToLower()]
                    if (-not $type) { $type = 'application/octet-stream' }
                    Send $ctx 200 $type ([IO.File]::ReadAllBytes($full))
                } else {
                    Send $ctx 404 'text/plain; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes('No encontrado'))
                }
            }
        } catch {
            try { $ctx.Response.Abort() } catch {}
        }
    }
}

$rs = [runspacefactory]::CreateRunspace()
$rs.Open()
$ps = [powershell]::Create()
$ps.Runspace = $rs
[void]$ps.AddScript($serverScript).AddArgument($listener).AddArgument($sync)
[void]$ps.BeginInvoke()

# ---------- Barra flotante transparente ----------
Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Windows.Forms, System.Drawing

[xml]$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Subtitulos flotantes" Width="1000" Height="230" MinWidth="300" MinHeight="80"
        WindowStyle="None" AllowsTransparency="True" Background="Transparent"
        Topmost="True" ShowInTaskbar="False" ResizeMode="CanResizeWithGrip"
        WindowStartupLocation="Manual">
  <Border x:Name="Bg" CornerRadius="14" Background="#731B3260">
    <Grid>
      <StackPanel x:Name="Lines" VerticalAlignment="Bottom" Margin="22,12,22,18"/>
      <Button x:Name="BtnClose" Content="X" Width="28" Height="28"
              HorizontalAlignment="Right" VerticalAlignment="Top" Margin="0,6,8,0"
              Background="#99000000" Foreground="White" BorderThickness="0"
              FontWeight="Bold" Cursor="Hand" Opacity="0.25"
              ToolTip="Cerrar (se vuelve a abrir desde la pagina)"/>
    </Grid>
  </Border>
</Window>
'@

$window   = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $xaml))
$bg       = $window.FindName('Bg')
$panel    = $window.FindName('Lines')
$btnClose = $window.FindName('BtnClose')

$wa = [System.Windows.SystemParameters]::WorkArea
$window.Left = $wa.Left + ($wa.Width - $window.Width) / 2
$window.Top  = $wa.Top + $wa.Height - $window.Height - 30

function Hide-Bar { $window.Hide(); $sync.visible = $false }
function Show-Bar { $window.Show(); $window.Topmost = $true; $sync.visible = $true }

$window.Add_MouseLeftButtonDown({ try { $window.DragMove() } catch {} })
$window.Add_MouseEnter({ $btnClose.Opacity = 1 })
$window.Add_MouseLeave({ $btnClose.Opacity = 0.25 })
$btnClose.Add_Click({ Hide-Bar })
$window.Add_Closing({ param($s, $e) $e.Cancel = $true; Hide-Bar })
$window.Add_KeyDown({ param($s, $e) if ($e.Key -eq 'Escape') { Hide-Bar } })

$fontFam = New-Object System.Windows.Media.FontFamily('Segoe UI, Malgun Gothic, Microsoft YaHei, Yu Gothic UI, Meiryo')
$script:align = 'Center'

function Add-Line([string]$text, [double]$size, [string]$color, [bool]$bold, [double]$op) {
    $tb = New-Object System.Windows.Controls.TextBlock
    $tb.Text = $text
    $tb.FontSize = [Math]::Max(8, $size)
    $tb.FontFamily = $fontFam
    $tb.Foreground = New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.ColorConverter]::ConvertFromString($color))
    if ($bold) { $tb.FontWeight = [System.Windows.FontWeights]::SemiBold }
    $tb.TextWrapping = 'Wrap'
    $tb.TextAlignment = $script:align
    $tb.Opacity = $op
    $fx = New-Object System.Windows.Media.Effects.DropShadowEffect
    $fx.ShadowDepth = 1.5; $fx.BlurRadius = 6; $fx.Opacity = 1
    $fx.Color = [System.Windows.Media.Colors]::Black
    $tb.Effect = $fx
    [void]$panel.Children.Add($tb)
}

function Render-Overlay($json) {
    $d = $null
    if ($json) { try { $d = $json | ConvertFrom-Json } catch { return } }
    $fs = 38; $bgPct = 45
    if ($d) { $fs = [double]$d.fs; $bgPct = [double]$d.bg }
    # alfa minimo 1: la barra sigue pudiendose arrastrar aunque se vea invisible
    $a = [int][Math]::Round($bgPct * 2.55); if ($a -lt 1) { $a = 1 }; if ($a -gt 255) { $a = 255 }
    $bg.Background = New-Object System.Windows.Media.SolidColorBrush ([System.Windows.Media.Color]::FromArgb([byte]$a, 27, 50, 96))
    $script:align = 'Center'
    if ($d -and -not $d.center) { $script:align = 'Left' }
    $panel.Children.Clear()
    $lines = @()
    if ($d -and $d.lines) { $lines = @($d.lines) }
    if ($lines.Count -eq 0) {
        Add-Line 'Subtitulos en vivo - esperando voz...' ($fs * 0.5) '#DDDDDD' $false 1
        return
    }
    foreach ($l in $lines) {
        $op = 1.0; if ($l.interim) { $op = 0.7 }
        if ($d.showOrig -and $l.orig)       { Add-Line $l.orig ($fs * 0.5) '#D8E0EE' $false $op }
        if ($d.showReading -and $l.reading) { Add-Line $l.reading ($fs * 0.45) '#FFD28A' $false $op }
        if ($l.trans)                       { Add-Line $l.trans $fs '#FFFFFF' $true $op }
    }
}

# ---------- Icono junto al reloj ----------
$tray = New-Object System.Windows.Forms.NotifyIcon
try {
    $bmp = New-Object System.Drawing.Bitmap (Join-Path $root 'logo.png')
    $small = New-Object System.Drawing.Bitmap $bmp, 32, 32
    $tray.Icon = [System.Drawing.Icon]::FromHandle($small.GetHicon())
} catch {
    $tray.Icon = [System.Drawing.SystemIcons]::Information
}
$tray.Text = 'Subtitulos en vivo (activo)'
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$miOpen = $menu.Items.Add('Abrir pagina de subtitulos')
$miBar  = $menu.Items.Add('Mostrar / ocultar barra')
[void]$menu.Items.Add('-')
$miExit = $menu.Items.Add('Salir')
$miOpen.Add_Click({ Open-Browser })
$miBar.Add_Click({ if ($window.IsVisible) { Hide-Bar } else { Show-Bar } })
$miExit.Add_Click({
    $tray.Visible = $false
    $tray.Dispose()
    try { $listener.Stop() } catch {}
    [Environment]::Exit(0)
})
$tray.ContextMenuStrip = $menu
$tray.Add_DoubleClick({ Open-Browser })
$tray.Visible = $true
$tray.ShowBalloonTip(3000, 'Subtitulos en vivo', 'Ayudante activo. Para cerrarlo: clic derecho en este icono > Salir.', [System.Windows.Forms.ToolTipIcon]::Info)

# ---------- Ciclo principal ----------
$script:lastVer = -1
$timer = New-Object System.Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromMilliseconds(80)
$timer.Add_Tick({
    try {
        $c = $sync.cmd
        if ($c) {
            $sync.cmd = $null
            if ($c -eq 'show') { Show-Bar } elseif ($c -eq 'hide') { Hide-Bar }
        }
        if ($sync.ver -ne $script:lastVer) {
            $script:lastVer = $sync.ver
            Render-Overlay $sync.data
        }
    } catch {}
})
$timer.Start()

if (-not $NoBrowser) { Open-Browser }
[System.Windows.Threading.Dispatcher]::Run()
