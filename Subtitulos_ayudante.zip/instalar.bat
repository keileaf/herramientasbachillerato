@echo off
rem Instala el ayudante de Subtitulos en vivo (no requiere administrador)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
