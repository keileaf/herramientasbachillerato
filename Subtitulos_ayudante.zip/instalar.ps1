# Instalador del ayudante de Subtitulos en vivo - Colegio La Paz
# Copia los archivos a Documentos\Subtitulos en vivo, registra el enlace subtitulos://
# (para que la pagina lo pueda abrir) y crea un acceso directo en el Escritorio.
# No necesita permisos de administrador.

$ErrorActionPreference = 'Stop'
try {
    $src = Split-Path -Parent $MyInvocation.MyCommand.Path
    $dst = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Subtitulos en vivo'
    New-Item -ItemType Directory -Force -Path $dst | Out-Null

    # Si ya estaba corriendo, cerrarlo para poder reemplazar archivos
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -like '*Subtitulos en vivo*servidor.ps1*' } |
        ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Start-Sleep -Milliseconds 500

    foreach ($f in @('servidor.ps1', 'subtitulos.html', 'logo.png', 'LEEME.txt')) {
        $p = Join-Path $src $f
        if (Test-Path $p) {
            Copy-Item $p $dst -Force
            Unblock-File (Join-Path $dst $f) -ErrorAction SilentlyContinue
        }
    }

    $ps1 = Join-Path $dst 'servidor.ps1'
    $args1 = "-NoProfile -STA -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$ps1`""

    # Enlace subtitulos:// (solo para este usuario)
    $k = 'HKCU:\Software\Classes\subtitulos'
    New-Item -Path "$k\shell\open\command" -Force | Out-Null
    Set-ItemProperty -Path $k -Name '(default)' -Value 'URL:Subtitulos en vivo'
    New-ItemProperty -Path $k -Name 'URL Protocol' -Value '' -PropertyType String -Force | Out-Null
    Set-ItemProperty -Path "$k\shell\open\command" -Name '(default)' -Value "powershell.exe $args1 -NoBrowser"

    # Acceso directo en el Escritorio
    $ws = New-Object -ComObject WScript.Shell
    $lnk = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'Subtitulos en vivo.lnk'))
    $lnk.TargetPath = 'powershell.exe'
    $lnk.Arguments = $args1
    $lnk.WorkingDirectory = $dst
    $lnk.Description = 'Subtitulos en vivo - Colegio La Paz'
    $lnk.IconLocation = "$env:SystemRoot\System32\imageres.dll,109"
    $lnk.Save()

    Write-Host ""
    Write-Host "  Listo. El ayudante quedo instalado en:"
    Write-Host "  $dst"
    Write-Host ""
    Write-Host "  - La pagina de subtitulos ya puede abrir la barra transparente."
    Write-Host "  - Tambien tienes 'Subtitulos en vivo' en el Escritorio."
    Write-Host "  - Para cerrarlo: icono junto al reloj > clic derecho > Salir."
    Write-Host ""

    Start-Process powershell.exe -ArgumentList "$args1 -NoBrowser" -WindowStyle Hidden
} catch {
    Write-Host ""
    Write-Host "  No se pudo instalar: $($_.Exception.Message)"
    Write-Host ""
}
Read-Host "  Presiona Enter para cerrar"
